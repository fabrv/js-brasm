class punto3D {
  function () {
    var x= 0xfe12
    var y = '6'
  }
}