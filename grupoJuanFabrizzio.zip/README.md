# Brasm
Brasm is one more compiler.

## Usage
1. Clone the repo
```bash
git clone https://github.com/fabrv/js-brasm.git
cd js-brasm
```
2. Install dependencies
```bash
npm i
```
3. Start program
```bash
npm start [any source file | code.js]
```

## Config files
1. `tokensRegex.json`, includes all the tokens in Regex
2. `grammar.json`, includes the grammar rules